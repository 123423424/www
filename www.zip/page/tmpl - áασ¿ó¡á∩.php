<?php
	defined('CONSTANT5A') or die();    
    include "head_part.php"; // это подключит страницу хедер
?>
<!-- Ниже только содержание страницы без БОДИ, ХЕД и ФУТЕРА -->


<?php    
    include "foot_part.php"; // это подключит футерк
?>