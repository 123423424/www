<?php
	defined('CONSTANT5A') or die();  
?>
      <footer class="bs-docs-footer" role="contentinfo">
        <div class="container">

          <p>
            <a href="http://bootstrap-3.ru/">Предложения</a>
            по улучшению.
          </p>
          <ul class="bs-docs-footer-links muted">
            <li>Теукущая версия v4.1.1</li>
            <li>·</li>

            <li>
              <a target="_blank" href="/bootstraptheme.php">Инофрмация студентам</a>
            </li>
            <li>·</li>
            <li>
              <a href="/about.php">О проекте</a>
            </li>
            <li>·</li>
            <li>
              <a target="_blank" href="http://blog.getbootstrap.com/">Официальная группа</a>
            </li>
            <li>·</li>
            <li>
              <a target="_blank" href="https://github.com/twbs/bootstrap/issues?state=open">Вопросы</a>
            </li>
            <li>·</li>
            <li>
              <a target="_blank" href="https://github.com/twbs/bootstrap/releases">Партнерам</a>
            </li>
            <li>·</li>
            <li>
              <a target="_blank" href="https://github.com/twbs/bootstrap/releases">Авторам</a>
              (отправить резюме)
            </li>
          </ul>
          <div class="text-center">
            Спроектирован с любовью 
            <a target="_blank" href="http://сайтсайтов.рф/">СайтСайтов</a>
            .
          </div>
        </div>
      </footer>
      <script src="//<?=$_SERVER['SERVER_NAME']?>/js/vendor/bootstrap.js"></script>

      <script src="//<?=$_SERVER['SERVER_NAME']?>/js/plugins.js"></script>

      <script src="//<?=$_SERVER['SERVER_NAME']?>/js/main_order.js"></script>
      <script src="//<?=$_SERVER['SERVER_NAME']?>/js/main.js"></script>

  
      

      

</body>
    </html>