<?php
  echo "404";
  defined('CONSTANT5A') or die('mmm');  
?>